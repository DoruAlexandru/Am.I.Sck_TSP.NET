import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private readonly http: HttpClient) { }

  checkUser(body: any): Observable<any>{
    return this.http.post('http://192.168.100.8:5001/login',body);
  }

  registerUser(body: any): Observable<any>{
    return this.http.post('http://localhost:8080/registerUser',body);
  }

  getNewSymtom(body: any): Observable<any>{
    return this.http.post('http://localhost:8080/getNewSymptom',body);
  }
}

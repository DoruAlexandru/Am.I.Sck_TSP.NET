import { isNgTemplate } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-symptoms',
  templateUrl: './list-symptoms.component.html',
  styleUrls: ['./list-symptoms.component.scss']
})
export class ListSymptomsComponent implements OnInit {

  constructor() { }

  symptoms: SymptomList[] = [
    {
      name: '',
      severity: ''
    }
  ]

  ngOnInit(): void {
    var arrayOfKeys = Object.keys(localStorage);
    let i = 0;
    arrayOfKeys.forEach((item, index) => {
      if(item.includes('symp_')){
        this.symptoms[i].name=item.substr(item.indexOf('_')+1);
        this.symptoms[i].severity=localStorage.getItem(item);
        i++;
      }
    });
    console.log(this.symptoms)
  }
  

}

export interface SymptomList {
  name: string;
  severity: string|null;
}
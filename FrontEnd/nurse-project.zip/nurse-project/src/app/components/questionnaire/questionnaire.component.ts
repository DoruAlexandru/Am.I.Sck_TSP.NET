import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Item } from 'src/app/models/item';
import { Symptom } from 'src/app/models/symptom';

@Component({
  selector: 'app-questionnaire',
  templateUrl: './questionnaire.component.html',
  styleUrls: ['./questionnaire.component.scss'],
})
export class QuestionnaireComponent implements OnInit {
  constructor(private router:Router) {}

  show = false;

  symptoms: Symptom[] = [
    {
      symptomName: 'Fever',
      symptomDescription: 'desc dfgdfgdfgd',
      severities: [
        {
          name: 'Low',
          value: 'Low',
        },
        {
          name: 'Medium',
          value: 'Medium',
        },
        {
          name: 'High',
          value: 'High',
        },
        {
          name: 'Very high',
          value: 'Very high',
        }
      ]
    },
    {
      symptomName: 'Pain',
      symptomDescription: 'desc hhhhh',
      severities: [
        {
          name: 'Low',
          value: 'Low',
        },
        {
          name: 'Medium',
          value: 'Medium',
        },
        {
          name: 'High',
          value: 'High',
        },
        {
          name: 'Very high',
          value: 'Very high',
        }
      ]
    },
    {
      symptomName: 'Headache',
      symptomDescription: 'desc  hhhhfdhdfhdhdfh',
      severities: [
        {
          name: 'Low',
          value: 'Low',
        },
        {
          name: 'Medium',
          value: 'Medium',
        },
        {
          name: 'High',
          value: 'High',
        },
        {
          name: 'Very high',
          value: 'Very high',
        }
      ]
    }
  ];


  ngOnInit(): void {

  }

  showQuestionnaire(): void {
    this.show = true;
  }

  getSubmitedSymptoms(event: any): void {
  console.log(event);
  }

  public listSymptoms(): void {
    this.router.navigate(['listSymptoms']);
  }

}

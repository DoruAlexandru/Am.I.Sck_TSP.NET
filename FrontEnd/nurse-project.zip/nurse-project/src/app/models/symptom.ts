import { Item } from "./item";

export interface Symptom {
  symptomName: string;
  symptomDescription: string;
  formControlName?: string;
  severities: Item[];
}
